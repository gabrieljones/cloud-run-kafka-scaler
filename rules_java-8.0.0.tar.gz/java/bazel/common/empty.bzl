"""Placeholder for glob"""
